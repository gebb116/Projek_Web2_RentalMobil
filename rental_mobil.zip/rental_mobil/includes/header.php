<?php 
// 1. Memulai session secara aman jika belum aktif
if (session_status() === PHP_SESSION_NONE) {
    session_start(); 
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Premium Car Rental</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&family=Inter:wght@300;400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top dynamic-navbar">
    <div class="container">
        <a class="navbar-brand font-montserrat fw-bold" href="index.php">
            <i class="fa-solid fa-car-side text-warning me-2"></i>DRIVE<span class="text-warning">EASE</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto font-inter align-items-lg-center">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="armada.php">Armada</a></li>
                <li class="nav-item"><a class="nav-link" href="syarat.php">Syarat & Ketentuan</a></li>
                <li class="nav-item"><a class="nav-link" href="tentang.php">Tentang Kami</a></li>
                
                <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) : ?>
                    <li class="nav-item ms-lg-2">
                        <span class="nav-link text-warning fw-semibold">
                            <i class="fa-solid fa-circle-user me-1"></i> Halo, <?= htmlspecialchars($_SESSION['nama_user']); ?>
                        </span>
                    </li>
                    <li class="nav-item ms-lg-2">
                        <a class="btn btn-outline-danger btn-sm px-3 rounded-pill fw-bold my-2 my-lg-0" href="logout_user.php">
                            <i class="fa-solid fa-right-from-bracket me-1"></i> Keluar
                        </a>
                    </li>
                <?php else : ?>
                    <li class="nav-item ms-lg-2">
                        <a class="btn btn-outline-warning btn-sm px-3 rounded-pill fw-bold my-2 my-lg-0" href="login_user.php">
                            <i class="fa-solid fa-right-to-bracket me-1"></i> Login
                        </a>
                    </li>
                <?php endif; ?>
            </ul>

            <?php if (isset($_SESSION['user_logged_in']) && $_SESSION['user_logged_in'] === true) : ?>
                <a href="armada.php" class="btn btn-warning ms-lg-3 px-4 rounded-pill fw-bold">Pesan Sekarang</a>
            <?php else : ?>
                <a href="login_user.php" class="btn btn-warning ms-lg-3 px-4 rounded-pill fw-bold">Pesan Sekarang</a>
            <?php endif; ?>
            
        </div>
    </div>
</nav>