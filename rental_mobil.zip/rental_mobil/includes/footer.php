<footer class="bg-dark text-white pt-5 pb-3">
    <div class="container text-center text-md-start">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5 class="fw-bold text-warning mb-3">DRIVEEASE</h5>
                <p class="text-muted">Layanan rental mobil premium dan terpercaya untuk kebutuhan perjalanan bisnis, keluarga, maupun wisata Anda.</p>
            </div>
            <div class="col-md-4 mb-4 ps-md-5">
                <h5 class="fw-bold mb-3">Menu Cepat</h5>
                <ul class="list-unstyled">
                    <li><a href="armada.php" class="text-muted text-decoration-none">Daftar Armada</a></li>
                    <li><a href="syarat.php" class="text-muted text-decoration-none">Syarat & Ketentuan</a></li>
                    <li><a href="tentang.php" class="text-muted text-decoration-none">Hubungi Kami</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-4">
                <h5 class="fw-bold mb-3">Kontak</h5>
                <p class="text-muted"><i class="fa-solid fa-location-dot me-2"></i> Jl. Raya Utama No. 123, Jakarta</p>
                <p class="text-muted"><i class="fa-solid fa-phone me-2"></i> +62 812-3456-7890</p>
            </div>
        </div>
        <hr class="bg-secondary">
        <div class="text-center text-muted font-inter" style="font-size: 0.9rem;">
            &copy; 2026 DriveEase Rental. All Rights Reserved.
            <a href="admin/dashboard.php" class="text-secondary ms-2 text-decoration-none" style="transition: color 0.3s;" onmouseover="this.style.color='#ffc107'" onmouseout="this.style.color='#6c757d'">
                <i class="fa-solid fa-lock ms-1"></i> Login Admin
            </a>
        </div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
    // 1. Dapatkan nama file yang sedang dibuka di browser (misal: armada.php)
    var currentPage = window.location.pathname.split("/").pop();
    
    // Jika membuka root folder tanpa nama file, set otomatis ke index.php
    if (currentPage === "") {
        currentPage = "index.php";
    }

    // 2. Ambil semua elemen tautan menu navbar
    var menuLinks = document.querySelectorAll('.navbar-nav .nav-link');

    menuLinks.forEach(function(link) {
        // Hapus class 'active' bawaan HTML statis agar tidak bentrok
        link.classList.remove('active');
        
        // Ambil isi atribut href (misal: armada.php)
        var targetPage = link.getAttribute('href');

        // 3. Jika nama file URL cocok dengan tujuan href menu, pasang warna kuning emas
        if (currentPage === targetPage) {
            link.classList.add('page-active');
        }
    });
});
</script>
</body>
</html>