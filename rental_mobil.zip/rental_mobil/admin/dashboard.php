<?php
session_start();
// Pasang pengunci halaman: jika belum login, kembalikan paksa ke halaman login.php
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}
// Menghubungkan ke database (naik 1 folder ke folder utama)
include '../includes/koneksi.php';

// Mengambil semua data pesanan digabung dengan data mobil yang disewa
$query = mysqli_query($koneksi, "SELECT pesanan.*, mobil.nama_mobil 
                                 FROM pesanan 
                                 JOIN mobil ON pesanan.id_mobil = mobil.id_mobil 
                                 ORDER BY pesanan.tgl_buat DESC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin | DriveEase Management</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f9fa; }
        .sidebar { height: 100vh; background-color: #212529; color: #fff; position: fixed; width: 240px; }
        .main-content { margin-left: 240px; padding: 30px; }
        .nav-link { color: #adb5bd; }
        .nav-link:hover, .nav-link.active { color: #fff; background-color: rgba(255,255,255,0.1); border-radius: 5px; }
    </style>
</head>
<body>

    <div class="sidebar p-3">
        <h4 class="text-center fw-bold text-warning mb-4 font-montserrat"><i class="fa-solid fa-car-rear me-2"></i>Admin Panel</h4>
        <hr>
        <ul class="nav flex-column gap-2">
            <li class="nav-item">
                <a class="nav-link active p-3" href="dashboard.php"><i class="fa-solid fa-chart-line me-2"></i> Data Pesanan</a>
            </li>
            <li class="nav-item">
                <a class="nav-link p-3" href="../index.php" target="_blank"><i class="fa-solid fa-globe me-2"></i> Lihat Website</a>
            </li>
            <li class="nav-item mt-4">
                <a class="nav-link p-3 text-danger fw-bold" href="logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?')">
                    <i class="fa-solid fa-right-from-bracket me-2"></i> Keluar (Logout)
                </a>
            </li>
        </ul>
    </div>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h2 class="fw-bold text-dark">Manajemen Reservasi</h2>
                <p class="text-muted small mb-0">Kelola dan verifikasi transaksi sewa kendaraan pelanggan secara real-time.</p>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-3">
            <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="table-dark">
                            <tr>
                                <th class="p-3">Kode Booking</th>
                                <th>Pelanggan</th>
                                <th>Armada</th>
                                <th>Layanan</th>
                                <th>Durasi Sewa</th>
                                <th>Total Bayar</th>
                                <th>Dokumen</th>
                                <th>Status</th>
                                <th class="text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            if (mysqli_num_rows($query) > 0) {
                                while ($row = mysqli_fetch_assoc($query)) {
                                    // Hitung durasi tanggal
                                    $durasi = (strtotime($row['tgl_kembali']) - strtotime($row['tgl_jemput'])) / (60 * 60 * 24);
                                    if($durasi <= 0) $durasi = 1;

                                    // Badge warna status
                                    $badge_status = "bg-warning text-dark";
                                    if($row['status_pesanan'] == 'dikonfirmasi') $badge_status = "bg-primary";
                                    if($row['status_pesanan'] == 'selesai') $badge_status = "bg-success";
                                    if($row['status_pesanan'] == 'dibatalkan') $badge_status = "bg-danger";
                            ?>
                            <tr>
                                <td class="p-3 fw-bold text-secondary"><?= $row['kode_booking']; ?></td>
                                <td>
                                    <span class="d-block fw-bold text-dark"><?= $row['nama_pelanggan']; ?></span>
                                    <small class="text-muted"><i class="fa-brands fa-whatsapp text-success"></i> +62<?= $row['whatsapp']; ?></small>
                                </td>
                                <td><?= $row['nama_mobil']; ?></td>
                                <td><span class="badge bg-light text-dark text-capitalize border"><?= str_replace('-', ' ', $row['layanan']); ?></span></td>
                                <td>
                                    <small class="d-block text-dark fw-semibold"><?= date('d M Y', strtotime($row['tgl_jemput'])); ?></small>
                                    <small class="text-muted">s/d <?= date('d M Y', strtotime($row['tgl_kembali'])); ?> (<?= $durasi; ?> Hari)</small>
                                </td>
                                <!-- BAGIAN YANG TADI ERROR SUDAH DIPERBAIKI (DITAMBAHKAN TAG TD DI DEPAN) -->
                                <td class="fw-bold text-dark">Rp <?= number_format($row['total_bayar'], 0, ',', '.'); ?></td>
                                <td>
                                    <a href="../assets/images/dokumen/<?= $row['foto_ktp']; ?>" target="_blank" class="btn btn-outline-secondary btn-sm rounded-pill px-2 py-0" style="font-size: 0.75rem;">
                                        <i class="fa-solid fa-id-card me-1"></i>KTP
                                    </a>
                                </td>
                                <td><span class="badge <?= $badge_status; ?> text-uppercase"><?= $row['status_pesanan']; ?></span></td>
                                <td class="text-center">
                                    <form action="status_pesanan.php" method="POST" class="d-inline-block">
                                        <input type="hidden" name="id_pesanan" value="<?= $row['id_pesanan']; ?>">
                                        
                                        <select name="status_baru" class="form-select form-select-sm rounded-3 d-inline-block w-auto me-1" onchange="return confirm('Apakah Anda yakin ingin mengubah status pesanan ini?') ? this.form.submit() : false;">
                                            <option value="pending" <?= ($row['status_pesanan'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                            <option value="dikonfirmasi" <?= ($row['status_pesanan'] == 'dikonfirmasi') ? 'selected' : ''; ?>>Konfirmasi</option>
                                            <option value="selesai" <?= ($row['status_pesanan'] == 'selesai') ? 'selected' : ''; ?>>Selesai</option>
                                            <option value="dibatalkan" <?= ($row['status_pesanan'] == 'dibatalkan') ? 'selected' : ''; ?>>Batalkan</option>
                                        </select>
                                    </form>
                                </td>
                            </tr>
                            <?php 
                                }
                            } else {
                                echo '<tr><td colspan="9" class="text-center py-5 text-muted"><i class="fa-solid fa-folder-open fa-2x d-block mb-2"></i>Belum ada data pesanan masuk.</td></tr>';
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>
</html>