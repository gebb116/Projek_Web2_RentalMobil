<?php
session_start();
// Hapus semua data session aktif
session_unset();
session_destroy();

// Kembalikan ke halaman form login utama
header("Location: login.php");
exit();
?>