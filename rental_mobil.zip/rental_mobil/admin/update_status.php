<?php
// 1. Hubungkan ke database (sesuaikan jalur koneksi Anda jika berbeda)
include '../includes/koneksi.php';

// 2. Pastikan ada data ID dan Status yang dikirim melalui URL
if (isset($_GET['id']) && isset($_GET['status'])) {
    $id_pesanan = $_GET['id'];
    $status_baru = $_GET['status'];

    // 3. Amankan input data untuk mencegah SQL Injection
    $id_pesanan = mysqli_real_escape_string($koneksi, $id_pesanan);
    $status_baru = mysqli_real_escape_string($koneksi, $status_baru);

    // 4. Jalankan perintah SQL untuk memperbarui status
    $query = "UPDATE pesanan SET status = '$status_baru' WHERE id = '$id_pesanan'";
    $hasil = mysqli_query($koneksi, $query);

    if ($hasil) {
        // Jika berhasil, kembalikan halaman ke daftar status pesanan admin
        header("Location: status_pesanan.php?pesan=sukses_update");
        exit();
    } else {
        echo "Gagal memperbarui status: " . mysqli_error($koneksi);
    }
} else {
    echo "Akses tidak sah!";
}
?>