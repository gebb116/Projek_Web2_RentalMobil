<?php
session_start();
// Hubungkan ke database
include '../includes/koneksi.php';

$error = '';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Cek ketersediaan username dan password di tabel admin
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$username' AND password='$password'");
    
    if (mysqli_num_rows($query) === 1) {
        // Jika cocok, buat session penanda login berhasil
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['username'] = $username;
        
        // Alihkan admin ke halaman utama dashboard
        header("Location: dashboard.php");
        exit();
    } else {
        $error = 'Username atau Password salah!';
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Admin | DriveEase</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body { background-color: #1e2125; height: 100vh; display: flex; align-items: center; justify-content: center; font-family: 'Segoe UI', sans-serif; }
        .login-card { width: 400px; background: #ffffff; border-radius: 15px; box-shadow: 0px 10px 30px rgba(0,0,0,0.3); }
    </style>
</head>
<body>

<div class="card login-card border-0 p-4">
    <div class="card-body">
        <div class="text-center mb-4">
            <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-car-rear text-warning me-2"></i>DRIVEEASE</h3>
            <p class="text-muted small">Silakan masuk untuk mengelola reservasi</p>
        </div>

        <?php if (!empty($error)) : ?>
            <div class="alert alert-danger py-2 rounded-3 small text-center" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-1"></i> <?= $error; ?>
            </div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="mb-3">
                <label class="form-label small fw-bold text-secondary">Username</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-user text-muted"></i></span>
                    <input type="text" name="username" class="form-control border-start-0" placeholder="Masukkan username" required autocomplete="off">
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label small fw-bold text-secondary">Password</label>
                <div class="input-group">
                    <span class="input-group-text bg-light border-end-0"><i class="fa-solid fa-lock text-muted"></i></span>
                    <input type="password" name="password" class="form-control border-start-0" placeholder="Masukkan password" required>
                </div>
            </div>
            <button type="submit" name="login" class="btn btn-warning w-100 fw-bold text-dark rounded-3 py-2">
                <i class="fa-solid fa-right-to-bracket me-2"></i>Masuk Ke Dashboard
            </button>
        </form>
    </div>
</div>

</body>
</html>