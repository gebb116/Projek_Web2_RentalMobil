<?php
include '../includes/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['id_pesanan'])) {
    $id_pesanan  = mysqli_real_escape_string($koneksi, $_POST['id_pesanan']);
    $status_baru = mysqli_real_escape_string($koneksi, $_POST['status_baru']);

    if (!empty($status_baru)) {
        // Update status di database
        mysqli_query($koneksi, "UPDATE pesanan SET status_pesanan = '$status_baru' WHERE id_pesanan = '$id_pesanan'");
    }
}

// Kembalikan halaman langsung ke dashboard setelah proses update selesai
header("Location: dashboard.php");
exit;
?>